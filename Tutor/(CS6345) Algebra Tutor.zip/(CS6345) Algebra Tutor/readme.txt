********************************IMPORTANT: README *********************************************

Before launching Algebra Tutor, MAKE SURE THAT THE .exe file and _Data folder are
in the same directory. 

The _Data folder contains all the game’s files and 
the .exe file needs it to properly run the game!

***********************************************************************************************


